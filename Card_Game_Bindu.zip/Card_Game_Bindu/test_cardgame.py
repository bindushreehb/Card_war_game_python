import unittest
import cardgame
import random

''' To run:
    python -m unittest test_cardgame.py'''
    
class TestCardGame(unittest.TestCase):
    
    def test_GenerateDeck(self):
        # To test shuffle function
        sample = [1,2,3]
        random.shuffle(sample)
        self.assertNotEqual(sample, [1,2,3])
        
    def  test_EmptyDrawPile(self):
        # To test if a player with an empty draw pile tries to draw a card, the discard pile is shuffled into the draw pile
        
        testa_cards = []
        testb_cards = []
        testa_discard = [10,7,8]
        testb_discard = [7,3,2]
        
        a_face,b_face,testa_cards,testb_cards,testa_discard,testb_discard = cardgame.show_topcard(testa_cards,testb_cards,testa_discard,testb_discard)
        self.assertNotEqual(testa_cards,[])
        self.assertNotEqual(testb_cards,[])
        self.assertEqual(testa_discard,[])
        self.assertEqual(testb_discard,[])
        
    def test_HigherCard(self):
        # To test when comparing two cards, the higher card should win.
        
        testa_face = 10
        testb_face = 4
        expectedmsg = "player1 wins the round"
        
        returnmsg = cardgame.compare_cards(testa_face,testb_face)
        self.assertEqual(expectedmsg,returnmsg)
        
    def test_SameValue(self):
        # To test when comparing two cards of the same value, the winner of the next round should win 4 cards.
        testa_cards = [1,6,9]
        testb_cards = [1,4,2]
        a_discard = []
        b_discard = []
        expectedmsg = "Player1 is the winner of the Game"
        
        returnmsg = cardgame.play_CardGame(testa_cards,testb_cards)
        self.assertEqual(expectedmsg,returnmsg)
  
        
if __name__ == '__main__':
    unittest.main()