#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""
Implement the card game. Rules are:

1. Distribution of 40 cards between two users(shuffled cards)
2. Each player plays a card. Higher card wins. Winner takes both cards.
3. If the cards show the same value, the winner of the next turn wins these cards(2-Cards kept aside and face up card of his own and opponents) as well
   Winner takes all cards.
4. Game is over when a player doesn't have any cards in both draw pile and discard pile. The player with
   cards remaining is the winner.
"""


#!/usr/bin/env python
import random
import sys

# Global Variables
a_discard = []
b_discard = []
a_cards = []
b_cards = []
keep_aside = []
keep_aside_value = 0
a_face = int()
b_face = int()

def generate_deck():
    # Generate a randomized deck of cards.
    
    deck=[1,2,3,4,5,6,7,8,9,10]*4
    random.shuffle(deck)
    return deck

def split_cards(deck):
    # Split 20 shuffled cards equally among 2 players
    
    global a_cards
    global b_cards
    
    half=(len(deck)/2)
    half=int(half)
    print("The shuffled Deck is :"+str(deck))   
    

    for x in range(0,half):
        a_cards.append(deck[x])
    print("\n  cards with player1 ")
    print( a_cards)
    

    for x in range(half,len(deck)):
        b_cards.append(deck[x])
    print("\n cards with player2 ")
    print( b_cards)
    
    return a_cards,b_cards

def show_topcard(pa_cards,pb_cards,pa_discard,pb_discard):
    # Shows facing cards, and if draw pile is empty then shuffle the discard pile and moves the card from discard pile to draw pile.
    
    global a_face
    global b_face 

    if pa_cards and pb_cards:
        a_face = pa_cards.pop()
        b_face = pb_cards.pop()
                
    elif (not pa_cards and pa_discard) or (not pb_cards and  pb_discard):
        print ("List a empty")
        if not pa_cards and pb_cards:
            print ("Player A out of Cards in Draw Deck, shuffle and add the cards from discard deck")
            random.shuffle(pa_discard)
            pa_cards.extend(pa_discard)
            pa_discard.clear()
            
        elif not pb_cards and pa_cards:
            print ("Player B out of Cards in Draw Deck, shuffle and add the cards from discard deck")
            random.shuffle(pb_discard)
            pb_cards.extend(pb_discard)
            pb_discard.clear()
            
        else:
            print("Player A and Player B out of Cards in Draw Deck, shuffle and add the cards from discard deck")
            random.shuffle(pa_discard)
            random.shuffle(pb_discard)
            pa_cards.extend(pa_discard)
            pb_cards.extend(pb_discard)
            pa_discard.clear()
            pb_discard.clear()
         
        if pa_cards and pb_cards:
            a_face = pa_cards.pop()
            b_face = pb_cards.pop()
            
    return a_face,b_face,pa_cards,pb_cards,pa_discard,pb_discard;
    
def compare_cards(pa_face, pb_face):
    # Compares the cards and adds the card to the winners discard pile
    
    global keep_aside_value
    global a_discard
    global b_discard
    global keep_aside
    msg = ""

   
    if pa_face > pb_face:
        a_discard.append(pa_face)
        a_discard.append(pb_face)
        
        if keep_aside_value>0:
           a_discard.extend(keep_aside)
           keep_aside.clear()
           keep_aside_value=0
           print("Cards Kept aside added to discard pile of Player A")            
        msg = "player1 wins the round"
      
    
    elif pa_face < pb_face:
        b_discard.append(pa_face)
        b_discard.append(pb_face)
        
        if keep_aside_value>0:
            b_discard.extend(keep_aside)
            keep_aside.clear()
            keep_aside_value=0
            print("Cards Kept aside added to discard pile of Player B")
        msg = "player2 wins the round"
    
    else:
        keep_aside.append(pa_face)
        keep_aside.append(pb_face)
        msg = "Tie again... Moving to Next Round!!"
    
    return msg;

def play_CardGame(pa_cards,pb_cards):
    # Call necessary functions at right order for the game to be played.
    
    global keep_aside_value
    global a_discard
    global b_discard
    global a_face
    global b_face
    global a_cards
    global b_cards
    
    a_cards = pa_cards
    b_cards = pb_cards
    
    print("\n\n The Game of Card Begins \n\n")
    print("*******************************************************************************")
    round = 1
    autoPlay = False;
    # to play until atleast 1 card is left with Player A or Player B
    while (a_cards or a_discard) and (b_cards or b_discard):
        # by using pop, we're playing from the end forward
        # last elements from each list is compared(pop() last in element is displayed first)
        # List comparison takes place from opposite direction list A[1....7] and List B[2....3]) 
        # here, 7 and 3 are compared first
        
        # to provide user the option of complete execution or step by step execution        
        if autoPlay == False:
            print("Click enter to pick card OR enter A for autoplay and get results")
            inputKey = input()
            if inputKey == "A":
                autoPlay = True
        
        a_face,b_face,a_cards,b_cards,a_discard,b_discard = show_topcard(a_cards,b_cards,a_discard,b_discard)
        
        if a_face == b_face:
            print("There is a tie")
            print("Cards Kept aside and proceeding to next Round")
            print("*******************************************************************************")
            keep_aside.append(a_face)
            keep_aside.append(b_face)
            keep_aside_value = len(keep_aside)
            
            # Open top cards of both the players            
            a_face,b_face,a_cards,b_cards,a_discard,b_discard = show_topcard(a_cards,b_cards,a_discard,b_discard)
            
            # Comparing the cards
            outputstr = compare_cards(a_face,b_face)
            print(outputstr)
           
            
        else:
            # Comparing the cards
            outputstr = compare_cards(a_face,b_face) 
            print(outputstr)
                        
        print ("Round %s: Player1 total_deck_cards: %s, Player2 total_deck_cards: %s" %(round, len(a_cards), len(b_cards))) 
        print ("          Player1 total_discard_cards: %s, Player2 total_discard_cards: %s" %(len(a_discard), len(b_discard)))
        print("           Player1's facing_card : %s,  Player2's facing_card : %s" %(a_face, b_face))
        print("*******************************************************************************")
        round =round+1
        
    if len(a_cards)==0 and len(a_discard)==0:
        result = "Player2 is the winner of the Game"
    elif len(b_cards)==0 and len(b_discard)==0:
        result = "Player1 is the winner of the Game"
    
    return result;

def main():
        
        deck = generate_deck() # Generate the deck of cards
        a_cards,b_cards=split_cards(deck) # Split the deck among two players
        resultstr = play_CardGame(a_cards,b_cards)# Play the game of cards
        print(resultstr)
        sys.exit("Game Over!!")
    
               
if __name__ == "__main__":
    main()

